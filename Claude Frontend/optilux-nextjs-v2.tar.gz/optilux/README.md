# Optilux — Eye Care Website (Next.js)

A pixel-perfect recreation of the **Optilux** eye care theme in **Next.js 15**, **Tailwind CSS v4**, and **TypeScript**. All content is driven by data files — zero hardcoding in pages.

---

## Quick Start

```bash
tar -xzf optilux-nextjs.tar.gz
cd optilux
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Pages

| Route | Page |
|-------|------|
| `/` | Homepage — hero, stats, about, expertise, testimonials, services, process, FAQ |
| `/about` | About Us — about section, expertise bars, doctors, stats |
| `/our-doctors` | 6-doctor grid with social links |
| `/services` | Services listing (image cards) |
| `/services/[slug]` | Service detail — sidebar nav, key benefits, image panel |
| `/pricing` | 3 pricing plans |
| `/faq` | Tabbed FAQ with accordion (client interactive) |
| `/testimonials` | Google-style review cards |
| `/blog` | Blog listing with categories |
| `/blog/[slug]` | Full article with related posts |
| `/shop` | Shop with filters, price slider, pagination |
| `/shop/[slug]` | Product detail — color picker, quantity, add-to-cart |
| `/contact` | 4-location grid + contact form |
| `/terms` | Terms and Conditions |
| `/privacy` | Privacy Policy |

---

## Project Structure

```
src/
  app/          → All pages (Next.js App Router)
  components/
    layout/     → Navbar, Footer
    ui/         → CTABanner, PageHero, StarRating, SectionLabel
  data/
    site.ts     → Nav, footer links, stats, contact
    services.ts → 6 services, expertise, sidebar
    doctors.ts  → 6 doctors
    content.ts  → Testimonials, FAQ, pricing
    shop.ts     → Products, blog posts, filter options
```

---

## Design Tokens

| | Value |
|-|-------|
| Primary | `#00B5A3` |
| Heading | `#1B3C4A` |
| Body | `#4A6572` |
| Footer bg | `#0B3547` |
| Mint bg | `#EAF8F6` |
| Font | DM Sans |

---

## Customization

- **Content** → Edit `src/data/*.ts` files
- **Colors** → `src/app/globals.css` + `tailwind.config.ts`
- **Images** → Replace Unsplash URLs in data files with your own, update `next.config.ts`
- **New service/blog/product** → Add array entry in the relevant data file; pages auto-generate
