"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useRef, useEffect } from "react";
import { ChevronDown, Menu, X, Heart, ShoppingCart, Search } from "lucide-react";
import { navLinks } from "@/data/site";

function OptiluxLogo() {
  return (
    <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
      <circle cx="20" cy="20" r="18" fill="#E5F8F6" />
      <path d="M20 4C11.163 4 4 11.163 4 20c5.5-4.5 11-6 16-6s10.5 1.5 16 6C36 11.163 28.837 4 20 4z" fill="#00B5A3" opacity="0.4"/>
      <path d="M4 20c0 8.837 7.163 16 16 16-4-3.5-6.5-9-6.5-16S14 9.5 20 6c-8.837 0-16 6.163-16 14z" fill="#00B5A3" opacity="0.6"/>
      <path d="M36 20c0-8.837-7.163-16-16-16 6 3.5 7 9 7 16s-2 12-7 16c8.837 0 16-7.163 16-16z" fill="#00B5A3"/>
      <circle cx="20" cy="20" r="4.5" fill="white"/>
      <circle cx="20" cy="20" r="2.5" fill="#00B5A3"/>
    </svg>
  );
}

export default function Navbar({ variant = "default" }: { variant?: "default" | "shop" }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [mobileExpanded, setMobileExpanded] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { setMobileOpen(false); setMobileExpanded(null); }, [pathname]);
  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current); }, []);

  const enter = (label: string) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setOpenDropdown(label);
  };
  const leave = () => { timerRef.current = setTimeout(() => setOpenDropdown(null), 180); };
  const isActive = (href: string) => href === "/" ? pathname === "/" : pathname.startsWith(href) && href !== "#";

  return (
    <header className="sticky top-0 z-50 bg-white shadow-[0_2px_16px_rgba(0,0,0,0.07)]">
      <div className="max-w-[1240px] mx-auto px-5">
        <div className="flex items-center justify-between h-[72px]">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 flex-shrink-0">
            <OptiluxLogo />
            <span className="text-[#1B3C4A] font-bold text-xl tracking-tight">Optilux</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-0.5">
            {navLinks.map((link) => (
              <div
                key={link.label}
                className="relative"
                onMouseEnter={() => link.hasDropdown && enter(link.label)}
                onMouseLeave={leave}
              >
                <Link
                  href={link.href}
                  className={`flex items-center gap-1 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors
                    ${isActive(link.href) ? "text-[#00B5A3]" : "text-[#1B3C4A] hover:text-[#00B5A3]"}`}
                >
                  {link.label}
                  {link.hasDropdown && (
                    <ChevronDown size={13} className={`text-[#A0B8C2] transition-transform ${openDropdown === link.label ? "rotate-180" : ""}`} />
                  )}
                </Link>

                {link.hasDropdown && link.children && openDropdown === link.label && (
                  <div className="absolute top-[calc(100%+8px)] left-0 min-w-[200px] bg-white rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.12)] border border-[#EEF5F7] overflow-hidden z-50">
                    {link.children.map((child) => (
                      <Link
                        key={child.label}
                        href={child.href}
                        className={`block px-4 py-3 text-[0.8125rem] transition-colors border-b border-[#F2F8FA] last:border-0
                          ${pathname === child.href ? "bg-[#EAF8F6] text-[#00B5A3] font-semibold" : "text-[#4A6572] hover:bg-[#EAF8F6] hover:text-[#00B5A3]"}`}
                      >
                        {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {variant === "shop" && (
              <>
                <div className="hidden sm:flex items-center gap-2 border border-[#E2EEF2] rounded-full px-3.5 py-1.5 bg-[#F7FBFC]">
                  <Search size={13} className="text-[#A0B8C2]" />
                  <input placeholder="search..." className="outline-none text-[0.8125rem] w-24 bg-transparent text-[#4A6572] placeholder:text-[#B8CFD8]" />
                </div>
                <button className="relative p-2 text-[#4A6572] hover:text-[#00B5A3] transition-colors">
                  <Heart size={18} />
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[#00B5A3] text-white text-[9px] font-bold rounded-full flex items-center justify-center">0</span>
                </button>
                <button className="relative p-2 text-[#4A6572] hover:text-[#00B5A3] transition-colors">
                  <ShoppingCart size={18} />
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[#00B5A3] text-white text-[9px] font-bold rounded-full flex items-center justify-center">10</span>
                </button>
              </>
            )}
            {variant === "default" && (
              <Link href="/contact" className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 bg-[#00B5A3] text-white text-sm font-semibold rounded-full hover:bg-[#009E8E] transition-colors whitespace-nowrap">
                Book Your Visit
              </Link>
            )}
            <button className="lg:hidden p-2 text-[#1B3C4A] hover:text-[#00B5A3] transition-colors" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-[#EEF5F7] pb-5">
            {navLinks.map((link) => (
              <div key={link.label}>
                <div
                  className="flex items-center justify-between py-3 px-1 cursor-pointer"
                  onClick={() => link.hasDropdown && setMobileExpanded(mobileExpanded === link.label ? null : link.label)}
                >
                  <Link
                    href={link.href}
                    className={`text-sm font-medium ${isActive(link.href) ? "text-[#00B5A3]" : "text-[#1B3C4A]"}`}
                    onClick={() => !link.hasDropdown && setMobileOpen(false)}
                  >
                    {link.label}
                  </Link>
                  {link.hasDropdown && (
                    <ChevronDown size={14} className={`text-[#A0B8C2] transition-transform ${mobileExpanded === link.label ? "rotate-180" : ""}`} />
                  )}
                </div>
                {link.hasDropdown && mobileExpanded === link.label && link.children && (
                  <div className="bg-[#F7FBFC] rounded-xl overflow-hidden mb-1">
                    {link.children.map((child) => (
                      <Link key={child.label} href={child.href} className="block px-4 py-2.5 text-[0.8125rem] text-[#4A6572] hover:text-[#00B5A3] border-b border-[#EEF5F7] last:border-0" onClick={() => setMobileOpen(false)}>
                        {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-3">
              <Link href="/contact" className="flex items-center justify-center w-full py-3 bg-[#00B5A3] text-white text-sm font-semibold rounded-full hover:bg-[#009E8E] transition-colors" onClick={() => setMobileOpen(false)}>
                Book Your Visit
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
