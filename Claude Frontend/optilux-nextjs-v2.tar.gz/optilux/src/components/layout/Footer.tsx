import Link from "next/link";
import { MapPin, Phone, Mail } from "lucide-react";
import { siteConfig, footerServices, footerAboutLinks } from "@/data/site";

function FacebookIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>;
}
function XIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>;
}
function WhatsappIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/></svg>;
}
function InstagramIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>;
}
function YoutubeIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58zM9.75 15.02V8.98L15.5 12l-5.75 3.02z"/></svg>;
}

const socialLinks = [
  { icon: FacebookIcon, href: "#", label: "Facebook" },
  { icon: XIcon, href: "#", label: "X (Twitter)" },
  { icon: WhatsappIcon, href: "#", label: "WhatsApp" },
  { icon: InstagramIcon, href: "#", label: "Instagram" },
  { icon: YoutubeIcon, href: "#", label: "YouTube" },
];

export default function Footer() {
  return (
    <footer className="bg-[#0B3547] text-white">
      <div className="max-w-[1240px] mx-auto px-5 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">

          {/* Brand */}
          <div className="lg:pr-4">
            <Link href="/" className="flex items-center gap-2.5 mb-5">
              <svg width="34" height="34" viewBox="0 0 40 40" fill="none">
                <circle cx="20" cy="20" r="18" fill="rgba(0,181,163,0.15)"/>
                <path d="M20 4C11.163 4 4 11.163 4 20c5.5-4.5 11-6 16-6s10.5 1.5 16 6C36 11.163 28.837 4 20 4z" fill="#00B5A3" opacity="0.4"/>
                <path d="M4 20c0 8.837 7.163 16 16 16-4-3.5-6.5-9-6.5-16S14 9.5 20 6c-8.837 0-16 6.163-16 14z" fill="#00B5A3" opacity="0.6"/>
                <path d="M36 20c0-8.837-7.163-16-16-16 6 3.5 7 9 7 16s-2 12-7 16c8.837 0 16-7.163 16-16z" fill="#00B5A3"/>
                <circle cx="20" cy="20" r="4.5" fill="white" opacity="0.9"/>
                <circle cx="20" cy="20" r="2.5" fill="#00B5A3"/>
              </svg>
              <span className="font-bold text-lg text-white tracking-tight">Optilux</span>
            </Link>
            <p className="text-sm text-[#7AAABB] leading-relaxed mb-6">
              At Optilux, we&apos;re dedicated to providing high-quality, personalized eye care for patients of all ages. Our skilled team uses the latest technology to ensure accurate exams, effective treatments, and clear, healthy vision for life.
            </p>
            <div className="flex items-center gap-2.5">
              {socialLinks.map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-8 h-8 rounded-full bg-[#1A4D62] flex items-center justify-center text-[#7AAABB] hover:bg-[#00B5A3] hover:text-white transition-all duration-200"
                >
                  <Icon />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold text-[0.9375rem] mb-5">Services</h4>
            <ul className="space-y-2.5">
              {footerServices.map((s) => (
                <li key={s.label}>
                  <Link href={s.href} className="text-sm text-[#7AAABB] hover:text-[#00B5A3] transition-colors leading-snug block">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* About */}
          <div>
            <h4 className="text-white font-semibold text-[0.9375rem] mb-5">About Us</h4>
            <ul className="space-y-2.5">
              {footerAboutLinks.map((s) => (
                <li key={s.label}>
                  <Link href={s.href} className="text-sm text-[#7AAABB] hover:text-[#00B5A3] transition-colors block">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold text-[0.9375rem] mb-5">Contact Us</h4>
            <ul className="space-y-5">
              <li className="flex gap-3 items-start">
                <div className="w-5 h-5 mt-0.5 flex-shrink-0 text-[#00B5A3]"><MapPin size={16} /></div>
                <div>
                  <p className="text-[0.8125rem] font-semibold text-white mb-0.5">Clinic Location</p>
                  <p className="text-sm text-[#7AAABB]">{siteConfig.contact.address}</p>
                </div>
              </li>
              <li className="flex gap-3 items-start">
                <div className="w-5 h-5 mt-0.5 flex-shrink-0 text-[#00B5A3]"><Phone size={16} /></div>
                <div>
                  <p className="text-[0.8125rem] font-semibold text-white mb-0.5">Call Us</p>
                  <a href={`tel:${siteConfig.contact.phone}`} className="text-sm text-[#7AAABB] hover:text-[#00B5A3] transition-colors">{siteConfig.contact.phone}</a>
                </div>
              </li>
              <li className="flex gap-3 items-start">
                <div className="w-5 h-5 mt-0.5 flex-shrink-0 text-[#00B5A3]"><Mail size={16} /></div>
                <div>
                  <p className="text-[0.8125rem] font-semibold text-white mb-0.5">Send a Message</p>
                  <a href={`mailto:${siteConfig.contact.email}`} className="text-sm text-[#7AAABB] hover:text-[#00B5A3] transition-colors">{siteConfig.contact.email}</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-[#1A4D62]">
        <div className="max-w-[1240px] mx-auto px-5 py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="text-xs text-[#4D7A8A]">© {new Date().getFullYear()} Optilux. All rights reserved.</span>
          <div className="flex items-center gap-5">
            <Link href="/terms" className="text-xs text-[#4D7A8A] hover:text-[#00B5A3] transition-colors">Terms & Conditions</Link>
            <Link href="/privacy" className="text-xs text-[#4D7A8A] hover:text-[#00B5A3] transition-colors">Privacy Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
