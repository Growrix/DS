import Link from "next/link";

export function CTABanner() {
  return (
    <section className="bg-[#00B5A3]">
      <div className="max-w-[1240px] mx-auto px-5 py-11 flex flex-col sm:flex-row items-center justify-between gap-6">
        <h2 className="text-white text-2xl md:text-[1.75rem] font-bold leading-tight">
          Clear Vision Starts Here. Schedule Your Eye Exam Today
        </h2>
        <Link
          href="/contact"
          className="flex-shrink-0 inline-flex items-center justify-center px-7 py-3 border-2 border-white text-white font-semibold rounded-full text-sm hover:bg-white hover:text-[#00B5A3] transition-all duration-200 whitespace-nowrap"
        >
          Book Your Visit
        </Link>
      </div>
    </section>
  );
}

export function PageHero({
  title,
  breadcrumb,
}: {
  title: string;
  breadcrumb: { label: string; href?: string }[];
}) {
  return (
    <section className="bg-[#EAF8F6] py-[56px] text-center">
      <div className="max-w-[1240px] mx-auto px-5">
        <h1 className="text-[#1B3C4A] text-4xl md:text-5xl font-bold mb-3 leading-tight">{title}</h1>
        <nav className="flex items-center justify-center gap-2 text-sm text-[#7A9BAA] flex-wrap">
          {breadcrumb.map((item, i) => (
            <span key={i} className="flex items-center gap-2">
              {i > 0 && <span className="text-[#A0C4CE]">›</span>}
              {item.href ? (
                <Link href={item.href} className="text-[#00B5A3] hover:underline">
                  {item.label}
                </Link>
              ) : (
                <span className="text-[#7A9BAA]">{item.label}</span>
              )}
            </span>
          ))}
        </nav>
      </div>
    </section>
  );
}

export function StarRating({ rating, max = 5, size = 14 }: { rating: number; max?: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: max }).map((_, i) => (
        <svg
          key={i}
          width={size}
          height={size}
          viewBox="0 0 20 20"
          fill="currentColor"
          className={i < Math.round(rating) ? "text-[#FFC107]" : "text-[#E0E0E0]"}
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return <span className="block text-[#00B5A3] text-xs font-semibold uppercase tracking-widest">{children}</span>;
}
