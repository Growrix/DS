import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";

const sections = [
  {
    title: "Information We Collect",
    content: "We collect information you provide directly to us, such as when you book an appointment, fill out a contact form, or communicate with us by phone or email. This may include your name, email address, phone number, and health information necessary to provide eye care services.",
  },
  {
    title: "How We Use Your Information",
    content: "We use the information we collect to schedule and manage your appointments, provide eye care services, send appointment reminders and follow-up communications, and improve our services and website.",
  },
  {
    title: "HIPAA Compliance",
    content: "As a healthcare provider, we comply with the Health Insurance Portability and Accountability Act (HIPAA). Your protected health information is handled in accordance with our Notice of Privacy Practices, available at our clinic.",
  },
  {
    title: "Data Security",
    content: "We implement appropriate technical and organizational security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.",
  },
  {
    title: "Contact Us",
    content: "If you have any questions about this Privacy Policy or our data practices, please contact us at contact@optilux.com or visit us at 100 S Main St, New York, NY.",
  },
];

export default function PrivacyPage() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title="Privacy Policy" breadcrumb={[{ label: "Home", href: "/" }, { label: "Privacy Policy" }]} />
        <section className="py-20 max-w-[820px] mx-auto px-5">
          <div className="space-y-8">
            {sections.map((s) => (
              <div key={s.title}>
                <h2 className="text-[#1B3C4A] text-lg font-bold mb-3">{s.title}</h2>
                <p className="text-sm text-[#4A6572] leading-7">{s.content}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
