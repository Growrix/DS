import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";

const sections = [
  {
    title: "1. Acceptance of Terms",
    content: "By accessing and using the Optilux website and services, you accept and agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our services.",
  },
  {
    title: "2. Medical Disclaimer",
    content: "The information provided on this website is for general informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your optometrist or other qualified health provider with any questions regarding an eye condition.",
  },
  {
    title: "3. Appointment Policy",
    content: "Appointments must be cancelled or rescheduled at least 24 hours in advance. Failure to do so may result in a cancellation fee. We reserve the right to reschedule appointments due to emergencies or unforeseen circumstances.",
  },
  {
    title: "4. Privacy",
    content: "Your use of our services is also governed by our Privacy Policy, which is incorporated into these Terms by reference. Please review our Privacy Policy to understand our practices.",
  },
  {
    title: "5. Changes to Terms",
    content: "Optilux reserves the right to modify these terms at any time. Changes will be effective immediately upon posting to the website. Your continued use of our services constitutes acceptance of the modified terms.",
  },
];

export default function TermsPage() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title="Terms & Conditions" breadcrumb={[{ label: "Home", href: "/" }, { label: "Terms & Conditions" }]} />
        <section className="py-20 max-w-[820px] mx-auto px-5">
          <div className="space-y-8">
            {sections.map((s) => (
              <div key={s.title}>
                <h2 className="text-[#1B3C4A] text-lg font-bold mb-3">{s.title}</h2>
                <p className="text-sm text-[#4A6572] leading-7">{s.content}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
