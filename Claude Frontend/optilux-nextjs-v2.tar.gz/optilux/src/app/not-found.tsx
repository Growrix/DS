import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main className="flex-1 flex items-center justify-center py-24 px-5">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 bg-[#EAF8F6] rounded-full flex items-center justify-center mx-auto mb-6">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#00B5A3" strokeWidth="1.5">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
              <line x1="11" y1="8" x2="11" y2="11"/><line x1="11" y1="14" x2="11.01" y2="14"/>
            </svg>
          </div>
          <h1 className="text-[#1B3C4A] text-6xl font-bold mb-3">404</h1>
          <h2 className="text-[#1B3C4A] text-xl font-bold mb-3">Page Not Found</h2>
          <p className="text-[#4A6572] text-sm mb-8 leading-relaxed">
            Sorry, the page you&apos;re looking for doesn&apos;t exist or has been moved.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/" className="inline-flex items-center justify-center px-7 py-3 bg-[#00B5A3] text-white font-semibold rounded-full text-sm hover:bg-[#009E8E] transition-colors">
              Back to Home
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center px-7 py-3 border-2 border-[#00B5A3] text-[#00B5A3] font-semibold rounded-full text-sm hover:bg-[#00B5A3] hover:text-white transition-all">
              Contact Us
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
