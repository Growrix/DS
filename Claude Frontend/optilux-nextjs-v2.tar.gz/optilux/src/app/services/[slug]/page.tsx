import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";
import { services, servicesSidebar } from "@/data/services";
import { CheckSquare2 } from "lucide-react";

export function generateStaticParams() {
  return services.map((s) => ({ slug: s.slug }));
}

export default async function ServiceSinglePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = services.find((s) => s.slug === slug);
  if (!service) notFound();

  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title={service.title} breadcrumb={[{ label: "Home", href: "/" }, { label: service.title }]} />

        <section className="py-20 max-w-[1240px] mx-auto px-5">
          <div className="grid lg:grid-cols-[220px_1fr_300px] gap-8">

            {/* ── Sidebar nav ─────────────────────────────── */}
            <div className="space-y-1.5">
              {servicesSidebar.map((item) => (
                <Link
                  key={item.label}
                  href={`/services/${item.slug}`}
                  className={`block px-4 py-3 rounded-xl text-sm font-medium transition-all
                    ${item.slug === slug
                      ? "bg-[#00B5A3] text-white shadow-sm"
                      : "bg-[#EAF8F6] text-[#1B3C4A] hover:bg-[#00B5A3] hover:text-white"
                    }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>

            {/* ── Main content ─────────────────────────────── */}
            <div>
              <h2 className="text-[#1B3C4A] text-[1.6rem] font-bold leading-tight mb-4">{service.title}</h2>
              <p className="text-[#4A6572] text-sm leading-relaxed mb-10">{service.description}</p>

              <h3 className="text-[#1B3C4A] text-xl font-bold mb-6">Key Benefits</h3>
              <div className="grid md:grid-cols-2 gap-6">
                {service.benefits.map((b) => (
                  <div key={b.title} className="flex gap-4">
                    <div className="w-11 h-11 bg-[#00B5A3] rounded-xl flex items-center justify-center flex-shrink-0">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#1B3C4A] mb-1">{b.title}</h4>
                      <p className="text-xs text-[#4A6572] leading-relaxed">{b.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ── Right image panel ────────────────────────── */}
            <div className="hidden lg:block">
              <div className="relative rounded-2xl overflow-hidden h-[300px]">
                <Image src={service.image} alt={service.title} fill className="object-cover" />
                <div className="absolute bottom-0 left-0 right-0 m-4 bg-[#00B5A3] rounded-xl p-4">
                  <p className="text-white text-xs font-medium leading-relaxed">
                    Personalized vision solutions to help you see the world with clarity and confidence.
                  </p>
                </div>
              </div>
              <Link href="/contact" className="mt-4 flex items-center justify-center w-full py-3.5 bg-[#00B5A3] text-white font-semibold rounded-full text-sm hover:bg-[#009E8E] transition-colors">
                Book Appointment
              </Link>
            </div>

          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
