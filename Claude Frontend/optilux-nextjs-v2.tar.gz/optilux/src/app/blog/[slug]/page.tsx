import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";
import { blogPosts } from "@/data/shop";

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export default async function BlogSinglePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) notFound();

  const related = blogPosts.filter((p) => p.slug !== slug && p.category === post.category).slice(0, 3);
  const moreRelated = blogPosts.filter((p) => p.slug !== slug && !related.includes(p)).slice(0, 3 - related.length);
  const allRelated = [...related, ...moreRelated].slice(0, 3);

  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title={post.category} breadcrumb={[{ label: "Home", href: "/" }, { label: "Blog", href: "/blog" }, { label: post.category }]} />

        <section className="py-20 max-w-[860px] mx-auto px-5">
          {/* Meta */}
          <div className="flex items-center flex-wrap gap-x-4 gap-y-2 text-sm text-[#7A9BAA] mb-7">
            <span className="inline-flex items-center gap-2">
              <Image src={post.authorAvatar} alt={post.author} width={28} height={28} className="rounded-full" />
              <span className="font-medium text-[#4A6572]">{post.author}</span>
            </span>
            <span>·</span>
            <span>{post.date}</span>
            <span>·</span>
            <span>{post.readTime}</span>
          </div>

          {/* Title */}
          <h1 className="text-[#1B3C4A] text-[1.75rem] md:text-[2rem] font-bold leading-tight mb-7">{post.title}</h1>

          {/* Featured image */}
          <div className="relative rounded-2xl overflow-hidden mb-10" style={{height:"340px"}}>
            <Image src={post.image} alt={post.title} fill className="object-cover" priority />
          </div>

          {/* Content */}
          <div
            className="text-sm text-[#4A6572] leading-relaxed [&_h2]:text-[#1B3C4A] [&_h2]:font-bold [&_h2]:text-xl [&_h2]:mt-10 [&_h2]:mb-4 [&_p]:mb-5 [&_p]:leading-7"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mt-10 pt-8 border-t border-[#E8F0F3]">
            {post.tags.map((tag) => (
              <span key={tag} className="bg-[#EAF8F6] text-[#00B5A3] text-xs font-semibold px-3.5 py-1.5 rounded-full">
                {tag}
              </span>
            ))}
          </div>
        </section>

        {/* Related posts */}
        {allRelated.length > 0 && (
          <section className="pb-20 max-w-[1240px] mx-auto px-5">
            <h2 className="text-[#1B3C4A] text-2xl font-bold mb-8">Related Articles</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {allRelated.map((p) => (
                <Link key={p.slug} href={`/blog/${p.slug}`} className="group">
                  <div className="relative rounded-2xl overflow-hidden mb-4" style={{height:"180px"}}>
                    <Image src={p.image} alt={p.title} fill className="object-cover transition-transform duration-500 group-hover:scale-105" />
                  </div>
                  <span className="text-xs text-[#00B5A3] font-semibold uppercase tracking-wider">{p.category}</span>
                  <h3 className="text-sm font-bold text-[#1B3C4A] group-hover:text-[#00B5A3] transition-colors leading-snug mt-1">{p.title}</h3>
                  <p className="text-xs text-[#7A9BAA] mt-1">{p.date}</p>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
