import Image from "next/image";
import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";
import { blogPosts } from "@/data/shop";

export default function BlogPage() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title="Blog" breadcrumb={[{ label: "Home", href: "/" }, { label: "Blog" }]} />

        <section className="py-20 max-w-[1240px] mx-auto px-5">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article key={post.slug} className="group flex flex-col">
                <Link href={`/blog/${post.slug}`}>
                  <div className="relative rounded-2xl overflow-hidden mb-5" style={{height:"210px"}}>
                    <Image src={post.image} alt={post.title} fill className="object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-[#081E29]/20 group-hover:bg-[#081E29]/10 transition-colors" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-[#00B5A3] text-white text-xs font-semibold px-3 py-1.5 rounded-full">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center flex-wrap gap-x-3 gap-y-1 text-xs text-[#7A9BAA] mb-3">
                    <Image src={post.authorAvatar} alt={post.author} width={22} height={22} className="rounded-full" />
                    <span className="font-medium text-[#4A6572]">{post.author}</span>
                    <span>·</span>
                    <span>{post.date}</span>
                    <span>·</span>
                    <span>{post.readTime}</span>
                  </div>
                  <h2 className="text-[#1B3C4A] font-bold text-[1rem] leading-snug mb-3 group-hover:text-[#00B5A3] transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-sm text-[#4A6572] leading-relaxed line-clamp-2 flex-1">{post.excerpt}</p>
                  <div className="mt-4">
                    <span className="text-[#00B5A3] text-sm font-semibold hover:underline">Read More →</span>
                  </div>
                </Link>
              </article>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
