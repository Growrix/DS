import Link from "next/link";
import Image from "next/image";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { CTABanner, StarRating, SectionLabel } from "@/components/ui/shared";
import { stats } from "@/data/site";
import { services, expertise } from "@/data/services";
import { testimonials, faqCategories } from "@/data/content";
import {
  CalendarDays, Eye, Stethoscope, Heart,
  ArrowUpRight, ChevronDown, Check,
} from "lucide-react";

/* ── Hero ─────────────────────────────────────────────────────────────────── */
function Hero() {
  return (
    <section className="relative min-h-[560px] bg-[#163040] overflow-hidden flex flex-col">
      {/* BG image */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?w=1600&q=80"
          alt="Eye care professional"
          fill priority
          className="object-cover object-center opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0D2B3A]/80 via-[#0D2B3A]/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative flex-1 max-w-[1240px] mx-auto px-5 pt-16 pb-28 w-full grid lg:grid-cols-[1fr_420px] gap-10 items-center">
        {/* Left */}
        <div>
          <h1 className="text-white font-bold leading-[1.18] mb-5" style={{ fontSize: "clamp(2.2rem,4.5vw,3.25rem)" }}>
            Expert Vision Care<br />and Trusted Eye<br />Specialists
          </h1>
          <p className="text-[#8BBECE] text-[1.0625rem] leading-relaxed mb-8 max-w-[430px]">
            Comprehensive eye exams with modern tools that provide accurate results while ensuring comfort and safety for every patient.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="/contact" className="inline-flex items-center justify-center px-8 py-3.5 bg-[#00B5A3] text-white font-semibold rounded-full text-[0.9375rem] hover:bg-[#009E8E] transition-colors">
              Book Now
            </Link>
          </div>
        </div>

        {/* Right – doctor card */}
        <div className="hidden lg:block relative self-end pb-6">
          <div className="relative w-[280px] h-[300px] rounded-2xl overflow-hidden ml-auto">
            <Image
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=600&q=80"
              alt="Our specialist"
              fill className="object-cover object-top"
            />
          </div>
          {/* Floating badge */}
          <div className="absolute bottom-0 right-[200px] bg-white rounded-2xl px-4 py-3 shadow-2xl flex items-center gap-3 w-[190px]">
            <div className="w-10 h-10 bg-[#EAF8F6] rounded-full flex items-center justify-center flex-shrink-0">
              <Eye size={18} className="text-[#00B5A3]" />
            </div>
            <div>
              <p className="text-[10px] text-[#7A9BAA] font-medium">Total</p>
              <p className="text-[0.8125rem] font-bold text-[#1B3C4A]">2.1k Happy Patients</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats bar (overlaps section) */}
      <div className="relative bg-[#00B5A3] z-10">
        <div className="max-w-[1240px] mx-auto px-5 py-5 grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <p className="text-white font-bold text-2xl md:text-3xl">{s.value}</p>
              <p className="text-white/75 text-xs mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── About ────────────────────────────────────────────────────────────────── */
function About() {
  return (
    <section className="py-20 max-w-[1240px] mx-auto px-5">
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        {/* Image collage */}
        <div className="grid grid-cols-2 gap-4 relative">
          <div className="rounded-2xl overflow-hidden h-[280px] mt-8">
            <Image src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=500&q=80" alt="Eye exam equipment" fill className="object-cover" style={{position:"relative",width:"100%",height:"100%"}} />
          </div>
          <div className="rounded-2xl overflow-hidden h-[280px]">
            <Image src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=500&q=80" alt="Our doctor" fill className="object-cover" style={{position:"relative",width:"100%",height:"100%"}} />
          </div>
        </div>

        {/* Content */}
        <div>
          <SectionLabel>About Us</SectionLabel>
          <h2 className="text-[#1B3C4A] text-[1.85rem] md:text-[2.1rem] font-bold leading-tight mt-3 mb-5">
            Professional and<br />Personalized Eye Care<br />Services
          </h2>
          <p className="text-[#4A6572] text-sm leading-relaxed mb-6">
            We provide complete vision care designed for all ages. From routine eye exams to advanced treatments, our dedicated team ensures your eyes remain healthy and your vision clear.
          </p>
          <div className="grid grid-cols-2 gap-x-6 gap-y-3 mb-8">
            {[
              "Comprehensive Eye Exams",
              "Latest Diagnostic Technology",
              "Gentle Care for Kids & Adults",
              "Flexible Appointment Scheduling",
            ].map((item) => (
              <div key={item} className="flex items-start gap-2">
                <Check size={15} className="text-[#00B5A3] flex-shrink-0 mt-0.5" strokeWidth={2.5} />
                <span className="text-sm text-[#4A6572] leading-snug">{item}</span>
              </div>
            ))}
          </div>
          <Link href="/about" className="inline-flex items-center justify-center px-7 py-3 bg-[#00B5A3] text-white font-semibold rounded-full text-sm hover:bg-[#009E8E] transition-colors">
            Book Your Visit
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ── Expertise ────────────────────────────────────────────────────────────── */
function Expertise() {
  return (
    <section className="pb-20 max-w-[1240px] mx-auto px-5">
      <h2 className="text-[#1B3C4A] text-2xl font-bold mb-9">Our Expertise</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-14 gap-y-7">
        {expertise.map((item) => (
          <div key={item.label}>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-[#1B3C4A] font-medium">{item.label}</span>
              <span className="text-sm text-[#1B3C4A] font-semibold">{item.percent}%</span>
            </div>
            <div className="h-[6px] bg-[#E2EEF2] rounded-full overflow-hidden">
              <div className="h-full bg-[#00B5A3] rounded-full" style={{ width: `${item.percent}%` }} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ── Testimonials ─────────────────────────────────────────────────────────── */
function Testimonials() {
  return (
    <section className="py-20 bg-[#EAF8F6]">
      <div className="max-w-[1240px] mx-auto px-5">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <SectionLabel>Testimonials</SectionLabel>
            <h2 className="text-[#1B3C4A] text-[1.85rem] md:text-[2.1rem] font-bold mt-3 leading-tight">
              What Our Patients Are Saying
            </h2>
            <p className="text-[#4A6572] text-sm mt-3 max-w-lg leading-relaxed">
              From comprehensive eye exams to advanced treatments, our clinic is dedicated to helping patients achieve clear, healthy vision with compassionate care.
            </p>
          </div>
          {/* Navigation dots hint */}
          <div className="flex gap-2 flex-shrink-0">
            <button className="w-9 h-9 rounded-full border-2 border-[#00B5A3] text-[#00B5A3] flex items-center justify-center hover:bg-[#00B5A3] hover:text-white transition-all text-sm">‹</button>
            <button className="w-9 h-9 rounded-full border-2 border-[#00B5A3] bg-[#00B5A3] text-white flex items-center justify-center hover:bg-[#009E8E] transition-all text-sm">›</button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.slice(0, 2).map((t) => (
            <div key={t.name} className="bg-white rounded-2xl p-7 shadow-sm">
              <div className="text-[3.5rem] text-[#00B5A3] leading-none mb-4 font-serif">&ldquo;</div>
              <p className="text-[#4A6572] text-sm leading-relaxed mb-6">{t.text}</p>
              <div className="flex items-center gap-3">
                <Image src={t.avatar} alt={t.name} width={46} height={46} className="rounded-full flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-[#1B3C4A] truncate">{t.name}</p>
                  <p className="text-xs text-[#7A9BAA] mt-0.5">{t.date}</p>
                </div>
                <StarRating rating={t.rating} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Services ─────────────────────────────────────────────────────────────── */
function Services() {
  return (
    <section className="py-20">
      <div className="max-w-[1240px] mx-auto px-5">
        <div className="text-center mb-12">
          <SectionLabel>Our Services</SectionLabel>
          <h2 className="text-[#1B3C4A] text-[1.85rem] md:text-[2.1rem] font-bold mt-3 leading-tight">
            Comprehensive Eye Care &<br />Optometry
          </h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => (
            <Link key={s.slug} href={`/services/${s.slug}`} className="group relative rounded-2xl overflow-hidden block" style={{ height: "220px" }}>
              <Image
                src={s.image} alt={s.title} fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#081E29]/95 via-[#081E29]/40 to-transparent" />
              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-5 flex items-end justify-between gap-3">
                <div>
                  <h3 className="text-white font-bold text-lg leading-tight">{s.title}</h3>
                  <p className="text-white/65 text-xs mt-1 line-clamp-1">{s.shortDesc}</p>
                </div>
                <div className="w-9 h-9 bg-[#00B5A3] rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-[#009E8E] transition-colors">
                  <ArrowUpRight size={16} className="text-white" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Process ──────────────────────────────────────────────────────────────── */
const processSteps = [
  { Icon: CalendarDays, title: "Book Appointment", desc: "Book your appointment online or by phone with our friendly staff." },
  { Icon: Eye,         title: "Eye Examination",  desc: "Receive a comprehensive eye exam with state-of-the-art diagnostics." },
  { Icon: Stethoscope, title: "Personalised Solutions", desc: "Get personalised recommendations for glasses, contacts, or treatments." },
  { Icon: Heart,       title: "Ongoing Care",     desc: "Enjoy clearer vision and ongoing care with regular follow-ups." },
];

function Process() {
  return (
    <section className="py-20 bg-[#163040] relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.08]">
        <Image src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1400&q=80" alt="" fill className="object-cover" />
      </div>
      <div className="relative max-w-[1240px] mx-auto px-5 text-center">
        <span className="block text-[#00B5A3] text-xs font-semibold uppercase tracking-widest mb-3">Our Process</span>
        <h2 className="text-white font-bold mb-14" style={{ fontSize: "clamp(1.75rem,3.5vw,2.25rem)" }}>
          Clear Steps to Better Vision
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {processSteps.map(({ Icon, title, desc }) => (
            <div key={title}>
              <div className="w-14 h-14 rounded-2xl bg-[#00B5A3]/15 border border-[#00B5A3]/30 flex items-center justify-center mx-auto mb-5">
                <Icon size={24} className="text-[#00B5A3]" />
              </div>
              <h3 className="text-white font-bold mb-2">{title}</h3>
              <p className="text-[#7AAABB] text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── FAQ ──────────────────────────────────────────────────────────────────── */
function FAQ() {
  const items = faqCategories[0].items.slice(0, 5);
  return (
    <section className="py-20">
      <div className="max-w-[1240px] mx-auto px-5 grid lg:grid-cols-2 gap-16 items-start">
        {/* Left */}
        <div>
          <SectionLabel>FAQ</SectionLabel>
          <h2 className="text-[#1B3C4A] text-[1.85rem] md:text-[2.1rem] font-bold mt-3 leading-tight">
            Everything You Should<br />Know About Eye Care
          </h2>
        </div>

        {/* Right */}
        <div>
          {/* Tab pills */}
          <div className="flex flex-wrap gap-2 mb-7">
            {faqCategories.map((cat, i) => (
              <span
                key={cat.label}
                className={`px-4 py-2 rounded-full text-[0.8125rem] font-semibold cursor-pointer transition-all ${
                  i === 0 ? "bg-[#00B5A3] text-white" : "text-[#7A9BAA] hover:text-[#00B5A3]"
                }`}
              >
                {cat.label}
              </span>
            ))}
          </div>

          {/* Items */}
          <div className="divide-y divide-[#E8F0F3]">
            {items.map((item) => (
              <div key={item.question} className="py-4 flex justify-between items-center gap-4 cursor-pointer group">
                <p className="text-sm font-medium text-[#1B3C4A] group-hover:text-[#00B5A3] transition-colors leading-snug">
                  {item.question}
                </p>
                <ChevronDown size={16} className="text-[#7A9BAA] flex-shrink-0" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Page ─────────────────────────────────────────────────────────────────── */
export default function HomePage() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <Hero />
        <About />
        <Expertise />
        <Testimonials />
        <Services />
        <Process />
        <FAQ />
        <CTABanner />
      </main>
      <Footer />
    </>
  );
}
