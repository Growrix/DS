import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";
import { pricingPlans } from "@/data/content";
import { Check } from "lucide-react";

export default function PricingPage() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title="Pricing" breadcrumb={[{ label: "Home", href: "/" }, { label: "Pricing" }]} />

        <section className="py-20 max-w-[1240px] mx-auto px-5">
          <div className="grid md:grid-cols-3 gap-6 max-w-[900px] mx-auto">
            {pricingPlans.map((plan) => (
              <div key={plan.name} className="rounded-2xl border border-[#DFF0EE] overflow-hidden flex flex-col">
                {/* Card header */}
                <div className="px-6 pt-7 pb-5">
                  <h3 className="text-[#1B3C4A] text-xl font-bold">{plan.name}</h3>
                  <p className="text-sm text-[#7A9BAA] mt-1">{plan.subtitle}</p>
                </div>

                {/* Price block */}
                <div className="bg-[#EAF8F6] mx-0 px-6 py-5">
                  <div className="flex items-baseline gap-1">
                    <span className="text-[#1B3C4A] font-bold" style={{fontSize:"2.5rem"}}>
                      ${plan.price}
                    </span>
                    <span className="text-[#7A9BAA] text-sm">{plan.period}</span>
                  </div>
                  <p className="text-xs text-[#7A9BAA] mt-1">
                    Normally <span className="line-through">${plan.originalPrice}</span>
                  </p>
                </div>

                {/* Features */}
                <div className="px-6 py-6 flex-1 space-y-3.5">
                  {plan.features.map((f, i) => (
                    <div key={i} className="flex items-center gap-2.5">
                      <Check size={15} className="text-[#00B5A3] flex-shrink-0" strokeWidth={2.5} />
                      <span className="text-sm text-[#4A6572]">
                        <strong className="text-[#1B3C4A] font-semibold">{f.highlight}</strong>
                        {f.rest}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <div className="px-6 pb-7">
                  <Link
                    href="/contact"
                    className="block text-center w-full py-3.5 bg-[#00B5A3] text-white font-semibold rounded-full text-sm hover:bg-[#009E8E] transition-colors"
                  >
                    {plan.cta}
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <p className="text-center text-xs text-[#7A9BAA] mt-8">
            *Prices may vary based on insurance and additional treatments.
          </p>
        </section>
      </main>
      <Footer />
    </>
  );
}
