"use client";
import { useState } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { PageHero } from "@/components/ui/shared";

const locations = [
  { city: "New York", address: "100 S Main St, New York, NY 10001", phone: "(212) 555-0199", email: "contact@optilux-ny.com" },
  { city: "Los Angeles", address: "742 S Olive St, Los Angeles, CA 90014", phone: "(310) 555-0147", email: "contact@optilux-la.com" },
  { city: "Chicago", address: "780 W Madison St, Chicago, IL 60661", phone: "(312) 555-0178", email: "ccontact@optilux-hi.com" },
  { city: "Miami", address: "500 Ocean Dr, Miami, FL 33139", phone: "(305) 555-0123", email: "miacontact@optilux-mi.com" },
];

const inputClass = "w-full px-4 py-3.5 border border-[#DFF0EE] rounded-xl text-sm text-[#1B3C4A] placeholder:text-[#A8C8D4] focus:outline-none focus:border-[#00B5A3] focus:ring-2 focus:ring-[#00B5A3]/10 transition-all bg-white";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [sent, setSent] = useState(false);

  const set = (k: string, v: string) => setForm({ ...form, [k]: v });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setForm({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <>
      <Navbar />
      <main className="flex-1">
        <PageHero title="Contact Us" breadcrumb={[{ label: "Home", href: "/" }, { label: "Contact Us" }]} />

        <section className="py-20 max-w-[1240px] mx-auto px-5">
          <div className="grid lg:grid-cols-[1fr_460px] gap-16 items-start">

            {/* ── Locations ── */}
            <div className="grid sm:grid-cols-2 gap-8">
              {locations.map((loc) => (
                <div key={loc.city}>
                  <h3 className="text-base font-bold text-[#1B3C4A] mb-2">{loc.city}</h3>
                  <p className="text-sm text-[#4A6572] mb-1 leading-relaxed">{loc.address}</p>
                  <p className="text-sm text-[#4A6572] mb-1">{loc.phone}</p>
                  <a href={`mailto:${loc.email}`} className="text-sm text-[#4A6572] hover:text-[#00B5A3] transition-colors">
                    {loc.email}
                  </a>
                </div>
              ))}
            </div>

            {/* ── Form ── */}
            <div>
              {sent ? (
                <div className="bg-[#EAF8F6] rounded-2xl p-10 text-center">
                  <div className="w-16 h-16 bg-[#00B5A3] rounded-full flex items-center justify-center mx-auto mb-5">
                    <svg width="28" height="28" fill="none" viewBox="0 0 24 24" stroke="white" strokeWidth="2.5">
                      <polyline points="20 6 9 17 4 12" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <h3 className="text-[#1B3C4A] font-bold text-xl mb-2">Message Sent!</h3>
                  <p className="text-sm text-[#4A6572]">We&apos;ll get back to you within 24 hours.</p>
                  <button onClick={() => setSent(false)} className="mt-6 text-sm text-[#00B5A3] font-semibold hover:underline">
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <input type="text" placeholder="Your Name" value={form.name} onChange={(e) => set("name", e.target.value)} className={inputClass} required />
                  <input type="email" placeholder="Your Email" value={form.email} onChange={(e) => set("email", e.target.value)} className={inputClass} required />
                  <input type="tel" placeholder="Your Phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} className={inputClass} />
                  <textarea
                    placeholder="Your Message"
                    rows={5}
                    value={form.message}
                    onChange={(e) => set("message", e.target.value)}
                    className={`${inputClass} resize-none`}
                    required
                  />
                  <button
                    type="submit"
                    className="w-full py-4 bg-[#00B5A3] text-white font-semibold rounded-full text-sm hover:bg-[#009E8E] transition-colors"
                  >
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
