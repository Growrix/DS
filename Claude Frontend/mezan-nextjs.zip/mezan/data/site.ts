// ─── Site Configuration ─────────────────────────────────────────────────────
export const siteConfig = {
  name: "Mezan",
  tagline: "Start Today",
  headline: "Mezan Services\nWorld Class Comprehensive",
  description:
    "Massa ultricies mi quis hendrerit dolor magna. Gravida et sollicitudin. Proin libero nunc consequat interdum varius sit amet mattis vulputate Massa ultricies mi quis hendrerit dolor magna. Gravida et sollicitudin. Proin libero nunc consequat interdum varius sit amet mattis vulputate nunc consequat interdum varius sit amet mattis vulputate.",
  address: "376 Branson Oval Suite 200, South Lon, Mexico",
  email: "mezan@example.com",
  phone: "+000 123 456 789",
  phone2: "+000 123 456 799",
  contactAddress: "No: 58 A, East Madison Street, Baltimore, MD, USA 4508",
  contactEmail: "info@example.com",
  socialLinks: {
    facebook: "#",
    pinterest: "#",
    youtube: "#",
    twitter: "#",
  },
  footerSocial: ["YT", "FB", "TW"],
  appLinks: {
    playStore: "#",
    appStore: "#",
  },
};

// ─── Navigation ──────────────────────────────────────────────────────────────
export const navLinks = [
  { label: "Home", href: "/", hasDropdown: true },
  { label: "About Us", href: "/about", hasDropdown: false },
  { label: "Shop", href: "/shop", hasDropdown: true },
  { label: "Mezan Blogs", href: "/blog", hasDropdown: true },
  { label: "Pages", href: "#", hasDropdown: true },
  { label: "Contact", href: "/contact", hasDropdown: false },
];

// ─── Hero Services ────────────────────────────────────────────────────────────
export const heroServices = [
  { label: "Plumber", icon: "plumber" },
  { label: "AC Service", icon: "ac" },
  { label: "Electrician", icon: "electrician" },
  { label: "Appliance", icon: "appliance" },
  { label: "Carpenter", icon: "carpenter" },
];

// ─── Products ────────────────────────────────────────────────────────────────
export type Product = {
  id: string;
  name: string;
  slug: string;
  category: string;
  priceMin: number;
  priceMax: number;
  originalPrice?: number;
  onSale: boolean;
  rating: number;
  reviewCount: number;
  images: string[];
  thumbnail: string;
  description: string;
  shortDescription: string;
  features: string[];
  additionalFeatures: string[];
  size?: string[];
  tags: string[];
  shipping: {
    cod: boolean;
    freeShipping: boolean;
    deliveryDays: string;
    easyReturns: boolean;
    paymentOptions: string;
  };
};

export const products: Product[] = [
  {
    id: "1",
    name: "Pipe Wrench",
    slug: "pipe-wrench",
    category: "hand-tools",
    priceMin: 13.5,
    priceMax: 14.3,
    onSale: true,
    rating: 4,
    reviewCount: 12,
    images: ["/products/pipe-wrench.png", "/products/pipe-wrench-2.png"],
    thumbnail: "/products/pipe-wrench.png",
    description:
      "Orci ac auctor augue mauris augue. Enim eu turpis egestas pretium aenean pharetra magna. Adipiscing enim eu turpis egestas pretium aenean pharetra magna ac. Risus quis varius quam quisque id diam vel quam elementum. Odio pellentesque commodo sed egestas egestas fringilla phasellus.",
    shortDescription:
      "Lacus vel facilisis volutpat est velit egestas. Curabitur gravida arcu ac tortor dignissim convallis aenean neque.",
    features: [
      "Vulputate dignissim suspendisse",
      "Urna molestie at elementum eu faci",
      "Nibh sed pulvinar proin gravida",
      "A scelerisque purus semper eget",
      "Eget scelerisque purus semper",
    ],
    additionalFeatures: [
      "Turpis nunc eget lorem dolor sed",
      "Interdum varius sit amet mattiseras",
      "Lacinia at quis risus sed vulputate",
      "Arcu cursus euismod quis viverra niba",
      "Viverra niba arcu cursus euismod quis",
    ],
    size: ["Small", "Medium", "Large"],
    tags: ["Plumbing Tools", "Hand Tools"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "2",
    name: "8\" Steel Plier",
    slug: "8-steel-plier",
    category: "hand-tools",
    priceMin: 9.7,
    priceMax: 10.6,
    onSale: true,
    rating: 5,
    reviewCount: 8,
    images: ["/products/steel-plier.png"],
    thumbnail: "/products/steel-plier.png",
    description:
      "High quality steel plier designed for professional use. Durable construction ensures long lasting performance.",
    shortDescription:
      "Professional grade steel plier for precision work.",
    features: [
      "Chrome vanadium steel",
      "Anti-slip grip handle",
      "Precision machined jaws",
      "Corrosion resistant",
      "Ergonomic design",
    ],
    additionalFeatures: [
      "Box joint construction",
      "Double-dipped handles",
      "Spring return action",
      "Induction hardened",
      "Lifetime warranty",
    ],
    tags: ["Hand Tools", "Electrical Tools"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "3",
    name: "Rubber Hand Gloves",
    slug: "rubber-hand-gloves",
    category: "safety-wear",
    priceMin: 13.4,
    priceMax: 14.15,
    onSale: true,
    rating: 3,
    reviewCount: 5,
    images: ["/products/rubber-gloves.png"],
    thumbnail: "/products/rubber-gloves.png",
    description:
      "Premium rubber hand gloves for safety and protection. Suitable for plumbing, electrical and general maintenance work.",
    shortDescription: "Heavy duty rubber gloves for professional protection.",
    features: [
      "Natural rubber material",
      "Slip resistant surface",
      "Comfortable fit",
      "Chemical resistant",
      "Washable and reusable",
    ],
    additionalFeatures: [
      "Ergonomic design",
      "Available in multiple sizes",
      "Meets safety standards",
      "Durable construction",
      "Easy to clean",
    ],
    tags: ["Safety Wear", "Carpenter Tools"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "4",
    name: "Handsaw",
    slug: "handsaw",
    category: "equipment",
    priceMin: 10.0,
    priceMax: 12.0,
    originalPrice: 12.0,
    onSale: true,
    rating: 4,
    reviewCount: 15,
    images: ["/products/handsaw.png"],
    thumbnail: "/products/handsaw.png",
    description:
      "Professional grade handsaw for precision cutting tasks. Suitable for wood, plastic and soft metals.",
    shortDescription: "Precision handsaw for professional carpentry.",
    features: [
      "Hardened steel blade",
      "Ergonomic handle",
      "Anti-friction coating",
      "Triple cut teeth",
      "Rust resistant",
    ],
    additionalFeatures: [
      "20 TPI fine cut",
      "Comfortable grip",
      "Blade cover included",
      "Flexible blade",
      "Precision ground teeth",
    ],
    tags: ["Carpenter Tools", "Equipment"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "5",
    name: "Metal Shovel",
    slug: "metal-shovel",
    category: "equipment",
    priceMin: 20.15,
    priceMax: 20.3,
    originalPrice: 20.3,
    onSale: true,
    rating: 4,
    reviewCount: 7,
    images: ["/products/metal-shovel.png"],
    thumbnail: "/products/metal-shovel.png",
    description:
      "Heavy duty metal shovel for construction and landscaping work. Forged steel blade for maximum durability.",
    shortDescription: "Durable metal shovel for heavy-duty applications.",
    features: [
      "Forged steel blade",
      "Fiberglass handle",
      "D-grip handle",
      "All weather use",
      "Extra long handle",
    ],
    additionalFeatures: [
      "Anti-corrosion coating",
      "Riveted construction",
      "Comfortable grip",
      "Balanced design",
      "Heavy duty use",
    ],
    tags: ["Equipment"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "6",
    name: "Hand Vacuum",
    slug: "hand-vacuum",
    category: "equipment",
    priceMin: 15.5,
    priceMax: 16.3,
    onSale: true,
    rating: 3,
    reviewCount: 20,
    images: ["/products/hand-vacuum.png", "/products/hand-vacuum-2.png", "/products/hand-vacuum-3.png"],
    thumbnail: "/products/hand-vacuum.png",
    description:
      "Orci ac auctor augue mauris augue. Enim eu turpis egestas pretium aenean pharetra magna. Adipiscing enim eu turpis egestas pretium aenean pharetra magna ac. Risus quis varius quam quisque id diam vel quam elementum. Odio pellentesque commodo sed egestas egestas fringilla phasellus. Vulputate enim nulla aliquet porttitor lacus.",
    shortDescription:
      "Lacus vel facilisis volutpat est velit egestas. Curabitur gravida arcu ac tortor dignissim convallis aenean neque.",
    features: [
      "Vulputate dignissim suspendisse",
      "Urna molestie at elementum eu faci",
      "Nibh sed pulvinar proin gravida",
      "A scelerisque purus semper eget",
      "Eget scelerisque purus semper",
    ],
    additionalFeatures: [
      "Turpis nunc eget lorem dolor sed",
      "Interdum varius sit amet mattiseras",
      "Lacinia at quis risus sed vulputate",
      "Arcu cursus euismod quis viverra niba",
      "Viverra niba arcu cursus euismod quis",
    ],
    size: ["Standard", "Compact"],
    tags: ["Equipment"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "7",
    name: "Plastic Tool Box",
    slug: "plastic-tool-box",
    category: "hardware-diy-tools",
    priceMin: 12.6,
    priceMax: 13.2,
    onSale: true,
    rating: 5,
    reviewCount: 11,
    images: ["/products/tool-box.png"],
    thumbnail: "/products/tool-box.png",
    description:
      "Heavy duty plastic tool box with multiple compartments. Ideal for organizing and storing tools.",
    shortDescription: "Durable plastic tool box for tool organization.",
    features: [
      "High-impact plastic",
      "Multiple compartments",
      "Secure latch closure",
      "Comfortable carry handle",
      "Stackable design",
    ],
    additionalFeatures: [
      "Removable tray",
      "Rust proof",
      "Large capacity",
      "Durable hinges",
      "UV resistant",
    ],
    tags: ["Carpenter Tools"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "8",
    name: "Cordless Drill",
    slug: "cordless-drill",
    category: "power-tools",
    priceMin: 12.65,
    priceMax: 12.8,
    originalPrice: 18.2,
    onSale: true,
    rating: 5,
    reviewCount: 30,
    images: ["/products/cordless-drill.png"],
    thumbnail: "/products/cordless-drill.png",
    description:
      "Professional cordless drill with lithium ion battery. Variable speed and torque settings for all drilling tasks.",
    shortDescription: "High performance cordless drill for professionals.",
    features: [
      "18V lithium ion battery",
      "Variable speed trigger",
      "Keyless chuck",
      "Built-in LED light",
      "Ergonomic grip",
    ],
    additionalFeatures: [
      "2 speed settings",
      "15 torque positions",
      "Battery level indicator",
      "Lightweight design",
      "Fast charging",
    ],
    size: ["Standard", "Compact"],
    tags: ["Power Tools", "Electrical Tools"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
  {
    id: "9",
    name: "Metal Hand Jigsaw",
    slug: "metal-hand-jigsaw",
    category: "hardware-diy-tools",
    priceMin: 9.5,
    priceMax: 9.75,
    originalPrice: 9.75,
    onSale: true,
    rating: 4,
    reviewCount: 6,
    images: ["/products/jigsaw.png"],
    thumbnail: "/products/jigsaw.png",
    description:
      "Professional metal hand jigsaw for precision cutting. Suitable for metal, wood and plastic cutting tasks.",
    shortDescription: "Precision metal hand jigsaw for professional use.",
    features: [
      "High carbon steel",
      "Adjustable tension",
      "Comfortable handle",
      "Replaceable blade",
      "Accurate cuts",
    ],
    additionalFeatures: [
      "Rotating handle",
      "Blade storage",
      "Non-slip grip",
      "Durable frame",
      "Easy blade change",
    ],
    tags: ["Carpenter Tools", "Hardware DIY Tools"],
    shipping: {
      cod: true,
      freeShipping: true,
      deliveryDays: "2-5 Business Day",
      easyReturns: true,
      paymentOptions: "Credit Card , Debit Card , Net Banking , Wallets , EMI , COD",
    },
  },
];

// ─── Product Categories ───────────────────────────────────────────────────────
export const productCategories = [
  { label: "Equipment", slug: "equipment", count: 4 },
  { label: "Hand Tools", slug: "hand-tools", count: 3 },
  { label: "Hardware DIY Tools", slug: "hardware-diy-tools", count: 2 },
  { label: "Power Tools", slug: "power-tools", count: 2 },
  { label: "Safety Wear", slug: "safety-wear", count: 1 },
];

export const productTags = ["Carpenter Tools", "Electrical Tools", "Plumbing Tools"];

// ─── Homepage Sections ────────────────────────────────────────────────────────
export const homeSections = [
  {
    id: "safety-wear",
    title: "Safety Wear And\nHand Tool",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Nam euismod, ipsum a dictum pretium, lacus risus tempor nisi, nec fermentum ipsum nisi sit amet justo. Integer euismod quam sed urna tincidunt, id interdum quam placerat.",
    categorySlug: "safety-wear",
    productIds: ["1", "2", "3"],
  },
  {
    id: "equipment",
    title: "Equipment",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Nam euismod, ipsum a dictum pretium, lacus risus tempor nisi, nec fermentum ipsum nisi sit amet justo. Integer euismod quam sed urna tincidunt, id interdum quam placerat.",
    categorySlug: "equipment",
    productIds: ["4", "5", "6"],
  },
  {
    id: "hardware",
    title: "Hardware And\nPower Tools",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Nam euismod, ipsum a dictum pretium, lacus risus tempor nisi, nec fermentum ipsum nisi sit amet justo. Integer euismod quam sed urna tincidunt, id interdum quam placerat.",
    categorySlug: "hardware-diy-tools",
    productIds: ["7", "8", "9"],
  },
];

// ─── CTA Banner ───────────────────────────────────────────────────────────────
export const ctaBanner = {
  text: "Several variations of Lorem Ipsum passages can be found, although most have been altered in some way with injected humor, ut pharetra sit amet aliquam id, commodo elit at imperdiet dui accumsan sit amet nulla. Sit amet tellus cras adipiscing. Please call",
  phones: ["+000 123 456 789", "+000 123 456 799"],
  cta: "Get In Touch",
};

// ─── About Page ───────────────────────────────────────────────────────────────
export const aboutContent = {
  subtitle: "Our Friendly Team",
  title: "Home And Businesses\nInstallation Services",
  description:
    "Phasellus Malesuada Pretium leo pulvinar sit. velit facilisi luctus mauris. Integer ullamcorper blandit nunc consequat. Augue interdum velit malesuada fames ac turpis. Maecenas ut leo vitae purus condimentum dignissim.",
  projectsCount: "560+",
  projectsLabel: "Projects Done",
  features: [
    {
      icon: "consultation",
      title: "Earliest Consultation",
      desc: "Nullam pharetra eu erat volutpat commodo. Adipiscing enim eu turpis egestas pretium aenean pharetra magna.",
    },
    {
      icon: "solution",
      title: "Customized Solution",
      desc: "Phasellus malesuada sollicitudin amet sit nulla. Velit tortuctor. Tempor faucibus. Ipsum in aliquet dui.",
    },
    {
      icon: "pricing",
      title: "Affordable Pricing",
      desc: "Sit orci eu lobortis sit amet varius. Venenatis. Tempor faucibus fermentum cras ullamcorper.",
    },
    {
      icon: "allinone",
      title: "All-In-One Service",
      desc: "Nullam vel nunc eu nisi eu mattis. Sit amet. Diam euismod. Venenatis vitae suscipit.",
    },
  ],
  videoCta: {
    subtitle: "Explore Our Services",
    title: "Simply Click To Get A Top Z Repair\n& Maintenance Work",
    desc: "Sed consequetur adipiscing mi purus. Phasellus faucibus duis cras. Porta accumsan porro.",
    buttons: ["Book Now", "More Videos"],
    stats: "200+ Continuing Contractors in Mundo",
  },
  marqueeText: "HIGH TECH ✦ INSTALLATION & REPAIR ✦ SERVICES BY PROFESSIONAL ✦ TECHNICIANS, AND DESIGNERS ✦ FOR COMPLETE ✦ NEEDS",
  stats: [
    { value: "980+", label: "Successful Services" },
    { value: "900+", label: "Satisfied Clients" },
    { value: "450+", label: "Professionals" },
    { value: "220+", label: "Global Stores" },
  ],
  servicesTitle: "Home & Commercial Services",
  servicesDesc:
    "Massa Laoipmtior atica elit. Arcu ultrices diam lacinia pretium dignissim parturient. Adipiscing ultrices pulvinar a ultricies. Habitant Mi. Malesuada.",
  serviceFeatures: [
    { icon: "licensed", title: "Licensed Technicians", desc: "Lorem ipsum dolor sit amet consectetur." },
    { icon: "rated", title: "Top Rated Service", desc: "Lorem ipsum dolor sit amet consectetur." },
    { icon: "timely", title: "Timely Services", desc: "Lorem ipsum dolor sit amet consectetur." },
    { icon: "quality", title: "Quality Services", desc: "Lorem ipsum dolor sit amet consectetur." },
  ],
  teamTitle: "Expert Technical Team",
  team: [
    { name: "Manila Atalbarto", role: "Master Plumber", slug: "manila-atalbarto" },
    { name: "Ambrogio Knee", role: "Electrician", slug: "ambrogio-knee" },
    { name: "Raffaele Giraldo", role: "AC Technician", slug: "raffaele-giraldo" },
    { name: "Susana Hazae", role: "Carpenter", slug: "susana-hazae" },
  ],
  faqTitle: "Frequently Asked Questions",
  faqSideTitle: "Still Have Doubts?",
  faqSideDesc: "$118 You Have Doubts? Give us a call and talk to one of our team members.",
  faqs: [
    {
      q: "How Often Should I Have My Plumbing Inspected?",
      a: "Nam consequat scelerisque commodo sed. Hendrerit morbi nunc tellus purus odio leo donec blandit congue. At ipsum quis mauris. Imperdiet at Pretium sodales.",
    },
    { q: "How Do I Choose The Right Masonry Contractor?", a: "" },
    { q: "What Are Some Signs That Masonry Work Needs Repair?", a: "" },
    { q: "What Should I Do If My Toilet Is Constantly Running?", a: "" },
    { q: "Do You Offer Free Financing Or Sustainable Options For Your Services?", a: "" },
  ],
  testimonialTitle: "Happy Customers",
  testimonials: [
    {
      name: "Consuela Daria",
      role: "Chairperson",
      rating: 5,
      text: "Elit Etiam Sit Amet Nisl Purus. Consequat Nel Ve Pretium Lacus Quam Id Leo. Tincidunt Augue Interdum Velit Euismod. Nunc Faucibus A Pellentesque Sit Amet. Porta Quis Diam Mollis At Varius Libero. Cras Convallis Tellus Id Ullamcorper Eu Lacinia. Pellentesque Massa Placerat. Consequat Nel Ve Pretium Lacus Quam Id Leo. Tincidunt Augue Interdum Velit Euismod. Nunc Faucibus A Pellentesque Sit Amet. Ullamcorper Per Morbi Tincidunt Ornare.",
    },
  ],
};

// ─── Footer ───────────────────────────────────────────────────────────────────
export const footerData = {
  description:
    "Duis ultricies libero sit amet aliquam fermentum. Nunc tincidunt dui in tempor. Maecenas ut leo vitae purus condimentum dignissim.",
  columns: [
    {
      title: "Information",
      links: [
        { label: "Request Service", href: "#" },
        { label: "Commercial Plumbing", href: "#" },
        { label: "Our Work", href: "#" },
        { label: "What We Do", href: "#" },
        { label: "Our Process", href: "#" },
        { label: "Reviews", href: "#" },
      ],
    },
    {
      title: "Support",
      links: [
        { label: "About", href: "/about" },
        { label: "Careers", href: "#" },
        { label: "Newsletter", href: "#" },
        { label: "Privacy Policy", href: "#" },
        { label: "Terms Of Use", href: "#" },
        { label: "Contact", href: "/contact" },
      ],
    },
  ],
  newsletter: {
    title: "Newsletter",
    desc: "Sunc fincidunt mollis dui in tempor. Duis ultricies libero sit amet.",
    disclaimer: "We don't spam. Unsubscription any time.",
  },
};
